<?php
    session_start();
    include './controller/insert.php';
    include './controller/select.php';
    $insert = new insert;
    $select = new select;
    $approveAsset = $select->approveAssetForUser($_SESSION['user']['id']);
    $declineAsset = $select->declineAssetForUser($_SESSION['user']['id']);
?>
<!DOCTYPE html>
<html dir="ltr" lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- Tell the browser to be responsive to screen width -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <title>AMS</title>
    <link rel="canonical" href="https://www.wrappixel.com/templates/ample-admin-lite/" />
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="css/favicon.png">
    <!-- Custom CSS -->
    <link href="css/chartist.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/dist/chartist-plugin-tooltip.css">
    <!-- Custom CSS -->
    <link href="css/style.min.css" rel="stylesheet">
</head>

<body>
    <!-- ============================================================== -->
    <!-- Preloader - style you can find in spinners.css -->
    <!-- ============================================================== -->
    <!-- <div class="preloader">
        <div class="lds-ripple">
            <div class="lds-pos"></div>
            <div class="lds-pos"></div>
        </div>
    </div> -->
    <!-- ============================================================== -->
    <!-- Main wrapper - style you can find in pages.scss -->
    <!-- ============================================================== -->
    <div id="main-wrapper" data-layout="vertical" data-navbarbg="skin5" data-sidebartype="full"
        data-sidebar-position="absolute" data-header-position="absolute" data-boxed-layout="full">
        <!-- ============================================================== -->
        <!-- Topbar header - style you can find in pages.scss -->
        <!-- ============================================================== -->
        <?php include_once 'includes/header.php'; ?>
        <!-- ============================================================== -->
        <!-- End Topbar header -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Left Sidebar - style you can find in sidebar.scss  -->
        <!-- ============================================================== -->
        <?php include_once 'includes/sidebar.php'; ?>
        <!-- ============================================================== -->
        <!-- End Left Sidebar - style you can find in sidebar.scss  -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Page wrapper  -->
        <!-- ============================================================== -->
        <div class="page-wrapper">
            <!-- ============================================================== -->
            <!-- Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <div class="page-breadcrumb bg-white">
                <div class="row align-items-center">
                    <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
                        <h4 class="page-title text-uppercase font-medium font-14">Dashboard</h4>
                    </div>
                    <div class="col-lg-9 col-sm-8 col-md-8 col-xs-12">
                        <div class="d-md-flex">
                            <!-- <ol class="breadcrumb ml-auto">
                                <li><a href="#">Dashboard</a></li>
                            </ol>
                            <a href="https://wrappixel.com/templates/ampleadmin/" target="_blank"
                                class="btn btn-danger  d-none d-md-block pull-right m-l-20 hidden-xs hidden-sm waves-effect waves-light">Upgrade
                                to Pro</a> -->
                        </div>
                    </div>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- ============================================================== -->
            <!-- End Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
            <!-- Container fluid  -->
            <!-- ============================================================== -->
            <div class="container-fluid">
                <!-- ============================================================== -->
                <!-- Three charts -->
                <!-- ============================================================== -->

                <!-- ============================================================== -->
                <!-- PRODUCTS YEARLY SALES -->
                <!-- ============================================================== -->
               <!--  <div class="row">
                    <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12">
                        <div class="white-box">
                            <h3 class="box-title">Products Yearly Sales</h3>
                            <div class="d-md-flex">
                                <ul class="list-inline d-flex ml-auto">
                                    <li class="pl-3">
                                        <h5><i class="fa fa-circle m-r-5 text-info"></i>Mac</h5>
                                    </li>
                                    <li class="pl-3">
                                        <h5><i class="fa fa-circle m-r-5 text-inverse"></i>Windows</h5>
                                    </li>
                                </ul>
                            </div>
                            <div id="ct-visits" style="height: 405px;">
                                <div class="chartist-tooltip" style="top: -17px; left: -12px;"><span
                                        class="chartist-tooltip-value">6</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div> -->
                <!-- ============================================================== -->
                <!-- RECENT SALES -->
                <!-- ============================================================== -->
                <div class="row" id="assetlist">
                    <div class="col-md-12 col-lg-12 col-sm-12">
                        <div class="white-box">
                            <div class="d-md-flex mb-3">
                                <h3 class="box-title mb-0">List Of  Approved Assests | Total : <?=(is_array($approveAsset)) ? count($approveAsset) : 0?></h3>
                                <div class="col-md-3 col-sm-4 col-xs-6 ml-auto">
                                    <!-- <select class="form-control row border-top">
                                        <option>March 2017</option>
                                        <option>April 2017</option>
                                        <option>May 2017</option>
                                        <option>June 2017</option>
                                        <option>July 2017</option>
                                    </select> -->
                                </div>
                            </div>
                            <div class="table-responsive">
                                <table class="table no-wrap">
                                    <thead>
                                        <tr>
                                            <th class="border-top-0">#</th>
                                          <!--   <th class="border-top-0">Unit/Department</th> -->
                                            <th class="border-top-0">Asset Name</th>
                                            <th class="border-top-0">Quantity</th>
                                            <th class="border-top-0">Status</th>
                                            <th class="border-top-0">Date Of Request</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <?php 
                                        if (is_array($approveAsset)) {
                                            foreach ($approveAsset as $value) {
                                            $i = 1;
                                    ?>
                                        <tr>
                                            <td><?=$i++?></td>
                                           <!--  <td><?=$value['unit']?></td> -->
                                            <td class="txt-oflo"><?=$value['name']?></td>
                                            <td><?=$value['quantity']?></td>
                                            <td><span class="text-success"><b><?=$value['status']?></b></span></td>
                                            <td class="txt-oflo"><?=$value['date_of_request']?></td>
                                           <!--  <td>
                                                <form method="post">
                                                    <input type="text" name="asset_id" value="<?=$value['id']?>" style="display: none;">
                                                    <button type="submit" name="approve" class="btn btn-sm btn-success text-white">Approve</button>
                                                </form>
                                            </td>
                                            <td>
                                                <form method="post">
                                                    <input type="text" name="asset_id" value="<?=$value['id']?>" style="display: none;">
                                                    <button type="submit" name="decline" class="btn btn-sm btn-danger">Decline</button>
                                                </form> 
                                            </td> -->
                                        </tr>
                                    <?php
                                        }
                                      }else{
                                     ?>


                                     <?php
                                        }
                                     ?>
                                       
                                        <!-- <tr>
                                            <td>2</td>
                                            <td class="txt-oflo">Library Department</td>
                                            <td><?=number_format(6000)?></td>
                                            <td class="text-danger"><?=number_format(2000)?></td>
                                            <td><span class="text-oflo"><?=number_format(8000)?></span></td>
                                        </tr>
                                        <tr>
                                            <td>4</td>
                                            <td class="txt-oflo">Security Department</td>
                                            <td><?=number_format(5000)?></td>
                                            <td class="text-danger"><?=number_format(1000)?></td>
                                            <td><span class="text-oflo"><?=number_format(6000)?></span></td>
                                        </tr>
                                        <tr>
                                            <td>5</td>
                                            <td class="txt-oflo">Medical Unit</td>
                                            <td><?=number_format(6000)?></td>
                                            <td class="text-danger"><?=number_format(500)?></td>
                                            <td><span class="text-oflo"><?=number_format(6500)?></span></td>
                                        </tr>
                                        <tr>
                                            <td>5</td>
                                            <td class="txt-oflo">ICT Unit</td>
                                            <td><?=number_format(3000)?></td>
                                            <td class="text-danger"><?=number_format(1500)?></td>
                                            <td><span class="text-oflo"><?=number_format(4500)?></span></td>
                                        </tr> -->
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- ============================================================== -->
                <!-- Recent Comments -->
                <!-- ============================================================== -->
                <div class="row">
                    <!-- .col -->
                    <div class="col-md-12 col-lg-8 col-sm-12">
<!--                         <div class="white-box">
                            <h3 class="box-title mb-0">Recent Comments</h3>
                            <div class="comment-center">
                                <div class="comment-body d-flex">
                                    <div class="user-img"> <img src="https://wrappixel.com/demos/admin-templates/ampleadmin/ample-admin-lite/plugins/images/users/pawandeep.jpg" alt="user"
                                            class="img-circle">
                                    </div>
                                    <div class="mail-contnet">
                                        <h5>Pavan kumar</h5><span class="time">10:20 AM 20 may 2016</span>
                                        <br>
                                        <div class="mb-3 mt-3">
                                            <span class="mail-desc">Donec ac condimentum massa. Etiam pellentesque
                                                pretium lacus. Phasellus ultricies dictum suscipit. Aenean commodo dui
                                                pellentesque molestie feugiat. Aenean commodo dui </span>
                                        </div>
                                        <a href="javacript:void(0)"
                                            class="btn btn btn-rounded btn-default btn-outline mb-2 mb-md-0 m-r-5"><i
                                                class="ti-check text-success m-r-5"></i>Approve</a><a
                                            href="javacript:void(0)" class="btn-rounded btn btn-default btn-outline"><i
                                                class="ti-close text-danger m-r-5"></i>
                                            Reject</a>
                                    </div>
                                </div>
                                <div class="comment-body d-flex">
                                    <div class="user-img"> <img src="https://wrappixel.com/demos/admin-templates/ampleadmin/ample-admin-lite/plugins/images/users/sonu.jpg" alt="user"
                                            class="img-circle">
                                    </div>
                                    <div class="mail-contnet">
                                        <h5>Sonu Nigam</h5><span class="time">10:20 AM 20 may 2016</span>
                                        <br>
                                        <div class="mb-3 mt-3">
                                            <span class="mail-desc">Donec ac condimentum massa. Etiam pellentesque
                                                pretium lacus. Phasellus ultricies dictum suscipit. Aenean commodo dui
                                                pellentesque molestie feugiat. Aenean commodo dui </span>
                                        </div>
                                    </div>
                                </div>
                                <div class="comment-body d-flex border-0">
                                    <div class="user-img"> <img src="https://wrappixel.com/demos/admin-templates/ampleadmin/ample-admin-lite/plugins/images/users/arijit.jpg" alt="user"
                                            class="img-circle">
                                    </div>
                                    <div class="mail-contnet">
                                        <h5>Arijit singh</h5><span class="time">10:20 AM 20 may 2016</span>
                                        <br>
                                        <div class="mb-3 mt-3">
                                            <span class="mail-desc">Donec ac condimentum massa. Etiam pellentesque
                                                pretium lacus. Phasellus ultricies dictum suscipit. Aenean commodo dui
                                                pellentesque molestie feugiat. Aenean commodo dui </span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div> -->
                    </div>
<!--                     <div class="col-lg-4 col-md-12 col-sm-12">
                        <div class="card">
                            <div class="card-heading">
                                CHAT LISTING
                            </div>
                            <div class="card-body">
                                <ul class="chatonline">
                                    <li>
                                        <div class="call-chat">
                                            <button class="btn btn-success text-white btn-circle btn" type="button">
                                                <i class="fas fa-phone"></i>
                                            </button>
                                            <button class="btn btn-info btn-circle btn" type="button">
                                                <i class="far fa-comments"></i>
                                            </button>
                                        </div>
                                        <a href="javascript:void(0)" class="d-flex align-items-center"><img
                                                src="https://wrappixel.com/demos/admin-templates/ampleadmin/ample-admin-lite/plugins/images/users/varun.jpg" alt="user-img" class="img-circle">
                                            <div class="ml-2">
                                                <span class="text-dark text-muted">Varun Dhavan <small
                                                        class="d-block text-success d-block">online</small></span>
                                            </div>
                                        </a>
                                    </li>
                                    <li>
                                        <div class="call-chat">
                                            <button class="btn btn-success text-white btn-circle btn" type="button">
                                                <i class="fas fa-phone"></i>
                                            </button>
                                            <button class="btn btn-info btn-circle btn" type="button">
                                                <i class="far fa-comments"></i>
                                            </button>
                                        </div>
                                        <a href="javascript:void(0)" class="d-flex align-items-center"><img
                                                src="https://wrappixel.com/demos/admin-templates/ampleadmin/ample-admin-lite/plugins/images/users/genu.jpg" alt="user-img" class="img-circle">
                                            <div class="ml-2">
                                                <span class="text-dark text-muted">Genelia
                                                    Deshmukh <small class="d-block text-warning">Away</small></span>
                                            </div>
                                        </a>
                                    </li>
                                    <li>
                                        <div class="call-chat">
                                            <button class="btn btn-success text-white btn-circle btn" type="button">
                                                <i class="fas fa-phone"></i>
                                            </button>
                                            <button class="btn btn-info btn-circle btn" type="button">
                                                <i class="far fa-comments"></i>
                                            </button>
                                        </div>
                                        <a href="javascript:void(0)" class="d-flex align-items-center"><img
                                                src="https://wrappixel.com/demos/admin-templates/ampleadmin/ample-admin-lite/plugins/images/users/ritesh.jpg" alt="user-img" class="img-circle">
                                            <div class="ml-2">
                                                <span class="text-dark text-muted">Ritesh
                                                    Deshmukh <small class="d-block text-danger">Busy</small></span>
                                            </div>
                                        </a>
                                    </li>
                                    <li>
                                        <div class="call-chat">
                                            <button class="btn btn-success text-white btn-circle btn" type="button">
                                                <i class="fas fa-phone"></i>
                                            </button>
                                            <button class="btn btn-info btn-circle btn" type="button">
                                                <i class="far fa-comments"></i>
                                            </button>
                                        </div>
                                        <a href="javascript:void(0)" class="d-flex align-items-center"><img
                                                src="https://wrappixel.com/demos/admin-templates/ampleadmin/ample-admin-lite/plugins/images/users/arijit.jpg" alt="user-img" class="img-circle">
                                            <div class="ml-2">
                                                <span class="text-dark text-muted">Arijit
                                                    Sinh <small class="d-block text-muted">Offline</small></span>
                                            </div>
                                        </a>
                                    </li>
                                    <li>
                                        <div class="call-chat">
                                            <button class="btn btn-success text-white btn-circle btn" type="button">
                                                <i class="fas fa-phone"></i>
                                            </button>
                                            <button class="btn btn-info btn-circle btn" type="button">
                                                <i class="far fa-comments"></i>
                                            </button>
                                        </div>
                                        <a href="javascript:void(0)" class="d-flex align-items-center"><img
                                                src="https://wrappixel.com/demos/admin-templates/ampleadmin/ample-admin-lite/plugins/images/users/govinda.jpg" alt="user-img"
                                                class="img-circle">
                                            <div class="ml-2">
                                                <span class="text-dark text-muted">Govinda
                                                    Star <small class="d-block text-success">online</small></span>
                                            </div>
                                        </a>
                                    </li>
                                    <li>
                                        <div class="call-chat">
                                            <button class="btn btn-success text-white btn-circle btn" type="button">
                                                <i class="fas fa-phone"></i>
                                            </button>
                                            <button class="btn btn-info btn-circle btn" type="button">
                                                <i class="far fa-comments"></i>
                                            </button>
                                        </div>
                                        <a href="javascript:void(0)" class="d-flex align-items-center"><img
                                                src="https://wrappixel.com/demos/admin-templates/ampleadmin/ample-admin-lite/plugins/images/users/hritik.jpg" alt="user-img" class="img-circle">
                                            <div class="ml-2">
                                                <span class="text-dark text-muted">John
                                                    Abraham<small class="d-block text-success">online</small></span>
                                            </div>
                                        </a>
                                    </li>
                                    <li>
                                        <div class="call-chat">
                                            <button class="btn btn-success text-white btn-circle btn" type="button">
                                                <i class="fas fa-phone"></i>
                                            </button>
                                            <button class="btn btn-info btn-circle btn" type="button">
                                                <i class="far fa-comments"></i>
                                            </button>
                                        </div>
                                        <a href="javascript:void(0)" class="d-flex align-items-center"><img
                                                src="https://wrappixel.com/demos/admin-templates/ampleadmin/ample-admin-lite/plugins/images/users/varun.jpg" alt="user-img" class="img-circle">
                                            <div class="ml-2">
                                                <span class="text-dark text-muted">Varun
                                                    Dhavan <small class="d-block text-success">online</small></span>
                                            </div>
                                        </a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div> -->
                    <!-- /.col -->
                </div>
            </div>
            <!-- ============================================================== -->
            <!-- End Container fluid  -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
            <!-- footer -->
            <!-- ============================================================== -->
            <!-- <footer class="footer text-center"> 2020 © Ample Admin brought to you by <a
                    href="https://www.wrappixel.com/">wrappixel.com</a>
            </footer> -->
            <!-- ============================================================== -->
            <!-- End footer -->
            <!-- ============================================================== -->
        </div>
        <!-- ============================================================== -->
        <!-- End Page wrapper  -->
        <!-- ============================================================== -->
    </div>
    <!-- ============================================================== -->
    <!-- End Wrapper -->
    <!-- ============================================================== -->
    <!-- ============================================================== -->
    <!-- All Jquery -->
    <!-- ============================================================== -->
<!--     <script src="https://wrappixel.com/demos/admin-templates/ampleadmin/ample-admin-lite/plugins/bower_components/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap tether Core JavaScript -->
    <script src="https://wrappixel.com/demos/admin-templates/ampleadmin/ample-admin-lite/plugins/bower_components/popper.js/dist/umd/popper.min.js"></script>
    <script src="https://wrappixel.com/demos/admin-templates/ampleadmin/ample-admin-lite/bootstrap/dist/js/bootstrap.min.js"></script>
    <script src="https://wrappixel.com/demos/admin-templates/ampleadmin/ample-admin-lite/js/app-style-switcher.js"></script>
    <script src="https://wrappixel.com/demos/admin-templates/ampleadmin/ample-admin-lite/plugins/bower_components/jquery-sparkline/jquery.sparkline.min.js"></script>
    <!--Wave Effects -->
    <script src="https://wrappixel.com/demos/admin-templates/ampleadmin/ample-admin-lite/js/waves.js"></script>
    <!--Menu sidebar -->
    <script src="https://wrappixel.com/demos/admin-templates/ampleadmin/ample-admin-lite/js/sidebarmenu.js"></script>
    <!--Custom JavaScript -->
    <script src="https://wrappixel.com/demos/admin-templates/ampleadmin/ample-admin-lite/js/custom.js"></script>
    <!--This page JavaScript -->
    <!--chartis chart-->
    <script src="https://wrappixel.com/demos/admin-templates/ampleadmin/ample-admin-lite/plugins/bower_components/chartist/dist/chartist.min.js"></script>
    <script src="https://wrappixel.com/demos/admin-templates/ampleadmin/ample-admin-lite/plugins/bower_components/chartist-plugin-tooltips/dist/chartist-plugin-tooltip.min.js"></script>
    <script src="https://wrappixel.com/demos/admin-templates/ampleadmin/ample-admin-lite/js/pages/dashboards/dashboard1.js"></script> -->
</body>


<!-- Mirrored from wrappixel.com/demos/admin-templates/ampleadmin/ample-admin-lite/dashboard.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 22 Jan 2021 04:31:01 GMT -->
</html>