<?php
    session_start();
    include_once './controller/select.php';
    $select = new select;
    $loginUser = $select->loginUser();

?>
<!DOCTYPE html>
<html dir="ltr" lang="en">


<!-- Mirrored from wrappixel.com/demos/admin-templates/ampleadmin/ample-admin-lite/dashboard.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 22 Jan 2021 04:31:01 GMT -->
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- Tell the browser to be responsive to screen width -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <title>AMS</title>
    <link rel="canonical" href="https://www.wrappixel.com/templates/ample-admin-lite/" />
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="css/favicon.png">
    <!-- Custom CSS -->
    <link href="css/chartist.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/dist/chartist-plugin-tooltip.css">
    <!-- Custom CSS -->
    <link href="css/style.min.css" rel="stylesheet">
</head>

<body>
    <!-- ============================================================== -->
    <!-- Preloader - style you can find in spinners.css -->
    <!-- ============================================================== -->
    <!-- <div class="preloader">
        <div class="lds-ripple">
            <div class="lds-pos"></div>
            <div class="lds-pos"></div>
        </div>
    </div> -->
    <!-- ============================================================== -->
    <!-- Main wrapper - style you can find in pages.scss -->
    <!-- ============================================================== -->
    <div class="container" style="margin-top: 90PX;">
     <div class="row justify-content-center">
        <div class="col-md-6">
        <h2 class="text-center p-2">AM-SYETEM</h2>
        <form method="post" class="">
        <?php
            if($loginUser == 'invalidUser'){
        ?>
             <div class="form-group">
                 <div class="alert alert-danger" role="alert">
                    Invalid Login Credentails. 
                </div>
             </div>
        <?php
            }
        ?>
          <div class="form-group ">
            <label class="col-form-label" for="formGroupExampleInput">User Name</label>
            <input type="text" name="username" class="form-control" id="formGroupExampleInput" placeholder="Enter Username">
          </div>
          <div class="form-group">
            <label class="col-form-label" for="formGroupExampleInput2">Password</label>
            <input type="password" name="password" class="form-control" id="formGroupExampleInput2" placeholder="Enter Password">
          </div>

         <div class="form-group ">
              <button type="submit" name="login" class="btn btn-success form-control text-white col-md-12">Sign In</button>
          </div>
        </form> 
    </div>
    </div>
    </div>       <!-- ============================================================== -->
    <!-- End Wrapper -->
    <!-- ============================================================== -->
    <!-- ============================================================== -->
    <!-- All Jquery -->
    <!-- ============================================================== -->
    <script src="https://wrappixel.com/demos/admin-templates/ampleadmin/ample-admin-lite/plugins/bower_components/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap tether Core JavaScript -->
    <script src="https://wrappixel.com/demos/admin-templates/ampleadmin/ample-admin-lite/plugins/bower_components/popper.js/dist/umd/popper.min.js"></script>
    <script src="https://wrappixel.com/demos/admin-templates/ampleadmin/ample-admin-lite/bootstrap/dist/js/bootstrap.min.js"></script>
    <script src="https://wrappixel.com/demos/admin-templates/ampleadmin/ample-admin-lite/js/app-style-switcher.js"></script>
    <script src="https://wrappixel.com/demos/admin-templates/ampleadmin/ample-admin-lite/plugins/bower_components/jquery-sparkline/jquery.sparkline.min.js"></script>
    <!--Wave Effects -->
    <script src="https://wrappixel.com/demos/admin-templates/ampleadmin/ample-admin-lite/js/waves.js"></script>
    <!--Menu sidebar -->
    <script src="https://wrappixel.com/demos/admin-templates/ampleadmin/ample-admin-lite/js/sidebarmenu.js"></script>
    <!--Custom JavaScript -->
    <script src="https://wrappixel.com/demos/admin-templates/ampleadmin/ample-admin-lite/js/custom.js"></script>
    <!--This page JavaScript -->
    <!--chartis chart-->
    <script src="https://wrappixel.com/demos/admin-templates/ampleadmin/ample-admin-lite/plugins/bower_components/chartist/dist/chartist.min.js"></script>
    <script src="https://wrappixel.com/demos/admin-templates/ampleadmin/ample-admin-lite/plugins/bower_components/chartist-plugin-tooltips/dist/chartist-plugin-tooltip.min.js"></script>
    <script src="https://wrappixel.com/demos/admin-templates/ampleadmin/ample-admin-lite/js/pages/dashboards/dashboard1.js"></script>
</body>


<!-- Mirrored from wrappixel.com/demos/admin-templates/ampleadmin/ample-admin-lite/dashboard.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 22 Jan 2021 04:31:01 GMT -->
</html>